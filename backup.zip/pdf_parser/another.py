# Import Module
import tabula

# Read PDF File
# this contain a list
df = tabula.read_pdf("Exhibit.pdf", pages = 1)[0]

# Convert into Excel File
df.to_csv('test')
